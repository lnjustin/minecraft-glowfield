package lnjustin.glowfield.mixin;

import lnjustin.glowfield.GlowField;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayDeque;

@Mixin(class_1937.class)
public abstract class ServerWorldMixin {
	@Unique
	private final ThreadLocal<ArrayDeque<BlockSnapshot>> glowfield$pendingSnapshots = ThreadLocal.withInitial(ArrayDeque::new);

	@Inject(method = "setBlockState", at = @At("HEAD"))
	private void glowfield$captureBefore(class_2338 pos, class_2680 state, int flags, int maxUpdateDepth, CallbackInfoReturnable<Boolean> cir) {
		class_1937 world = (class_1937) (Object) this;
		glowfield$pendingSnapshots.get().push(new BlockSnapshot(pos.method_10062(), world.method_8320(pos)));
	}

	@Inject(method = "setBlockState", at = @At("RETURN"))
	private void glowfield$emitAfter(class_2338 pos, class_2680 state, int flags, int maxUpdateDepth, CallbackInfoReturnable<Boolean> cir) {
		class_1937 world = (class_1937) (Object) this;
		BlockSnapshot snapshot = glowfield$pendingSnapshots.get().pop();
		if (cir.getReturnValueZ() && world instanceof class_3218 serverWorld) {
			GlowField.zones().onAnchorStateChanged(serverWorld, snapshot.pos(), snapshot.state(), world.method_8320(snapshot.pos()));
		}
	}

	@Unique
	private record BlockSnapshot(class_2338 pos, class_2680 state) {
	}
}
