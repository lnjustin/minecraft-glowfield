package lnjustin.glowfield.mixin;

import lnjustin.glowfield.GlowField;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4969;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4969.class)
public abstract class RespawnAnchorBlockMixin {
	@Inject(method = "charge", at = @At("HEAD"))
	private static void glowfield$captureChargeBefore(class_1297 charger, class_1937 world, class_2338 pos, class_2680 state, CallbackInfo ci) {
		if (!world.method_8608()) {
			GlowField.zones().onAnchorStateChanged((net.minecraft.class_3218) world, pos, state, world.method_8320(pos));
		}
	}
}
