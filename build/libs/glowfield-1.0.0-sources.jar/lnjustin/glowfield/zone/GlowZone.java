package lnjustin.glowfield.zone;

import lnjustin.glowfield.config.GlowFieldConfig;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_4969;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class GlowZone {
	private final UUID id;
	private final class_5321<class_1937> worldKey;
	private final UUID ownerUuid;
	private String ownerName;
	private String name;
	private final LinkedHashSet<class_2338> anchors;
	private final LinkedHashMap<UUID, String> members;
	private final class_238 bounds;
	private final Set<class_1923> coveredChunks;
	private int interactionProgress;
	private boolean hostileToNonMembers;
	private long remainingActiveTicks;
	private long lastUpdatedTick;
	private int hostilePlayerDeathsRemaining;
	private String lastAnnouncedMode;

	public GlowZone(UUID id, class_5321<class_1937> worldKey, UUID ownerUuid, String ownerName, String name, Collection<class_2338> anchors, int interactionProgress) {
		this(id, worldKey, ownerUuid, ownerName, name, anchors, interactionProgress, Map.of(), false, 0, -1, 0);
	}

	public GlowZone(
		UUID id,
		class_5321<class_1937> worldKey,
		UUID ownerUuid,
		String ownerName,
		String name,
		Collection<class_2338> anchors,
		int interactionProgress,
		Map<UUID, String> members,
		boolean hostileToNonMembers,
		long remainingActiveTicks,
		long lastUpdatedTick,
		int hostilePlayerDeathsRemaining
	) {
		this.id = id;
		this.worldKey = worldKey;
		this.ownerUuid = ownerUuid;
		this.ownerName = ownerName;
		this.name = name == null ? "" : name;
		this.anchors = new LinkedHashSet<>(anchors);
		this.members = new LinkedHashMap<>(members);
		this.bounds = computeBounds(this.anchors);
		this.coveredChunks = computeChunks(bounds);
		this.interactionProgress = Math.max(0, interactionProgress);
		this.hostileToNonMembers = hostileToNonMembers;
		this.remainingActiveTicks = Math.max(0, remainingActiveTicks);
		this.lastUpdatedTick = lastUpdatedTick;
		this.hostilePlayerDeathsRemaining = Math.max(0, hostilePlayerDeathsRemaining);
		this.lastAnnouncedMode = null;
	}

	public UUID id() {
		return id;
	}

	public class_5321<class_1937> worldKey() {
		return worldKey;
	}

	public UUID ownerUuid() {
		return ownerUuid;
	}

	public String ownerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName == null ? "" : ownerName;
	}

	public String name() {
		return name;
	}

	public void setName(String name) {
		this.name = name == null ? "" : name.trim();
	}

	public Set<class_2338> anchors() {
		return Set.copyOf(anchors);
	}

	public Map<UUID, String> members() {
		return Map.copyOf(members);
	}

	public class_238 bounds() {
		return bounds;
	}

	public class_238 runtimeBounds(class_3218 world) {
		return new class_238(bounds.field_1323, world.method_31607(), bounds.field_1321, bounds.field_1320, world.method_31600(), bounds.field_1324);
	}

	public class_238 particleBounds(GlowFieldConfig config) {
		double maxY = bounds.field_1322 + Math.max(0, config.particleRenderHeightBlocks - 1);
		return new class_238(bounds.field_1323, bounds.field_1322, bounds.field_1321, bounds.field_1320, maxY, bounds.field_1324);
	}

	public Set<class_1923> coveredChunks() {
		return Set.copyOf(coveredChunks);
	}

	public int interactionProgress() {
		return interactionProgress;
	}

	public boolean isMember(UUID uuid) {
		return ownerUuid.equals(uuid) || members.containsKey(uuid);
	}

	public boolean hostileToNonMembers() {
		return hostileToNonMembers;
	}

	public long remainingActiveTicks() {
		return remainingActiveTicks;
	}

	public int hostilePlayerDeathsRemaining() {
		return hostilePlayerDeathsRemaining;
	}

	public String currentModeKey(class_3218 world, GlowFieldConfig config) {
		ZoneState state = state(world, config);
		if (state == ZoneState.FORCE_FIELD && isHostileProtectionActive(world, config)) {
			return "hostile_force_field";
		}
		return state.serializedName();
	}

	public String currentModeLabel(class_3218 world, GlowFieldConfig config) {
		return switch (currentModeKey(world, config)) {
			case "partial" -> "Spawn Prevention Mode";
			case "force_field" -> "Force Field Mode";
			case "degrading" -> "Degrading Mode";
			case "hostile_force_field" -> "Hostile Force Field Mode";
			default -> "Inactive Mode";
		};
	}

	public boolean markModeAnnounced(String modeKey) {
		if (modeKey.equals(lastAnnouncedMode)) {
			return false;
		}
		lastAnnouncedMode = modeKey;
		return true;
	}

	public void addMember(UUID uuid, String name) {
		if (ownerUuid.equals(uuid)) {
			return;
		}
		members.put(uuid, name == null ? "" : name);
	}

	public void removeMember(UUID uuid) {
		members.remove(uuid);
	}

	public int minAnchorCharge(class_3218 world) {
		int minCharge = Integer.MAX_VALUE;
		for (class_2338 anchor : anchors) {
			class_2680 state = world.method_8320(anchor);
			if (!state.method_27852(net.minecraft.class_2246.field_23152) || !state.method_28498(class_4969.field_23153)) {
				return 0;
			}
			minCharge = Math.min(minCharge, state.method_11654(class_4969.field_23153));
		}
		return minCharge == Integer.MAX_VALUE ? 0 : minCharge;
	}

	public ZoneState state(class_3218 world, GlowFieldConfig config) {
		syncRuntime(world, config);
		int minCharge = minAnchorCharge(world);
		if (minCharge < config.partialMinCharge || remainingActiveTicks <= 0) {
			return ZoneState.INACTIVE;
		}
		if (hostileToNonMembers && hostilePlayerDeathsRemaining <= 0) {
			return ZoneState.INACTIVE;
		}
		if (interactionProgress >= config.degradingStateThreshold && minCharge > 0) {
			return ZoneState.DEGRADING;
		}
		if (minCharge >= config.forceFieldMinCharge) {
			return ZoneState.FORCE_FIELD;
		}
		return ZoneState.PARTIAL;
	}

	public boolean contains(class_2338 pos) {
		return pos.method_10263() >= bounds.field_1323 && pos.method_10263() <= bounds.field_1320
			&& pos.method_10260() >= bounds.field_1321 && pos.method_10260() <= bounds.field_1324;
	}

	public boolean contains(class_3218 world, class_238 box) {
		class_238 runtimeBounds = runtimeBounds(world);
		return box.field_1323 >= runtimeBounds.field_1323 && box.field_1320 <= runtimeBounds.field_1320 + 1.0
			&& box.field_1322 >= runtimeBounds.field_1322 && box.field_1325 <= runtimeBounds.field_1325 + 1.0
			&& box.field_1321 >= runtimeBounds.field_1321 && box.field_1324 <= runtimeBounds.field_1324 + 1.0;
	}

	public boolean recordInteractionAndShouldDegrade(int interactionCount, GlowFieldConfig config) {
		interactionProgress += interactionCount;
		if (interactionProgress < config.degradeEveryMobInteractions) {
			return false;
		}
		interactionProgress -= config.degradeEveryMobInteractions;
		return true;
	}

	public void resetProgress() {
		interactionProgress = 0;
	}

	public void syncRuntime(class_3218 world, GlowFieldConfig config) {
		long currentTick = world.method_75260();
		if (lastUpdatedTick < 0) {
			lastUpdatedTick = currentTick;
			if (remainingActiveTicks <= 0) {
				remainingActiveTicks = maxDurationTicks(world, config);
			}
			if (hostileToNonMembers && hostilePlayerDeathsRemaining <= 0) {
				hostilePlayerDeathsRemaining = Math.max(0, config.hostileFieldPlayerDeathLimit);
			}
			return;
		}

		long elapsed = Math.max(0, currentTick - lastUpdatedTick);
		lastUpdatedTick = currentTick;
		if (elapsed <= 0 || remainingActiveTicks <= 0 || minAnchorCharge(world) < config.partialMinCharge) {
			return;
		}

		remainingActiveTicks = Math.max(0, remainingActiveTicks - elapsed);
	}

	public void resetForCurrentCharge(class_3218 world, GlowFieldConfig config) {
		hostileToNonMembers = false;
		interactionProgress = 0;
		remainingActiveTicks = maxDurationTicks(world, config);
		lastUpdatedTick = world.method_75260();
		hostilePlayerDeathsRemaining = 0;
	}

	public void armAgainstNonMembers(class_3218 world, GlowFieldConfig config) {
		hostileToNonMembers = true;
		interactionProgress = 0;
		remainingActiveTicks = maxDurationTicks(world, config);
		lastUpdatedTick = world.method_75260();
		hostilePlayerDeathsRemaining = Math.max(0, config.hostileFieldPlayerDeathLimit);
	}

	public boolean consumesPlayerDeath(class_3218 world, GlowFieldConfig config) {
		syncRuntime(world, config);
		if (!hostileToNonMembers || hostilePlayerDeathsRemaining <= 0) {
			return false;
		}

		hostilePlayerDeathsRemaining--;
		if (hostilePlayerDeathsRemaining <= 0) {
			remainingActiveTicks = 0;
		}
		return true;
	}

	public boolean isHostileProtectionActive(class_3218 world, GlowFieldConfig config) {
		if (!config.allowNonMemberPlayerDamage) {
			return false;
		}

		return hostileToNonMembers && state(world, config) == ZoneState.FORCE_FIELD;
	}

	private long maxDurationTicks(class_3218 world, GlowFieldConfig config) {
		int minCharge = minAnchorCharge(world);
		if (minCharge < config.partialMinCharge) {
			return 0;
		}
		if (hostileToNonMembers && minCharge >= config.forceFieldMinCharge) {
			return Math.max(0, config.hostileForceFieldDurationTicks);
		}
		if (minCharge >= config.forceFieldMinCharge) {
			return Math.max(0, config.forceFieldDurationTicks);
		}
		return Math.max(0, config.partialFieldDurationTicks);
	}

	public void writeNbt(class_2487 tag) {
		tag.method_10582("id", id.toString());
		tag.method_10582("world", worldKey.method_29177().toString());
		tag.method_10582("owner_uuid", ownerUuid.toString());
		tag.method_10582("owner_name", ownerName == null ? "" : ownerName);
		tag.method_10582("name", name == null ? "" : name);
		tag.method_10569("interaction_progress", interactionProgress);
		tag.method_10556("hostile_to_non_members", hostileToNonMembers);
		tag.method_10544("remaining_active_ticks", remainingActiveTicks);
		tag.method_10544("last_updated_tick", lastUpdatedTick);
		tag.method_10569("hostile_player_deaths_remaining", hostilePlayerDeathsRemaining);

		class_2499 anchorList = new class_2499();
		for (class_2338 anchor : sortedAnchors(anchors)) {
			class_2487 anchorTag = new class_2487();
			anchorTag.method_10569("x", anchor.method_10263());
			anchorTag.method_10569("y", anchor.method_10264());
			anchorTag.method_10569("z", anchor.method_10260());
			anchorList.add(anchorTag);
		}
		tag.method_10566("anchors", anchorList);

		class_2499 memberList = new class_2499();
		for (Map.Entry<UUID, String> entry : members.entrySet()) {
			class_2487 memberTag = new class_2487();
			memberTag.method_10582("uuid", entry.getKey().toString());
			memberTag.method_10582("name", entry.getValue() == null ? "" : entry.getValue());
			memberList.add(memberTag);
		}
		tag.method_10566("members", memberList);

		class_2487 boundsTag = new class_2487();
		boundsTag.method_10569("min_x", (int) bounds.field_1323);
		boundsTag.method_10569("min_y", (int) bounds.field_1322);
		boundsTag.method_10569("min_z", (int) bounds.field_1321);
		boundsTag.method_10569("max_x", (int) bounds.field_1320);
		boundsTag.method_10569("max_y", (int) bounds.field_1325);
		boundsTag.method_10569("max_z", (int) bounds.field_1324);
		tag.method_10566("bounds", boundsTag);
	}

	public static GlowZone fromNbt(class_2487 tag) {
		List<class_2338> anchors = new ArrayList<>();
		class_2499 anchorList = tag.method_68569("anchors");
		for (int i = 0; i < anchorList.size(); i++) {
			class_2487 anchorTag = anchorList.method_68582(i);
			anchors.add(new class_2338(anchorTag.method_68083("x", 0), anchorTag.method_68083("y", 0), anchorTag.method_68083("z", 0)));
		}

		Map<UUID, String> members = new LinkedHashMap<>();
		class_2499 memberList = tag.method_68569("members");
		for (int i = 0; i < memberList.size(); i++) {
			class_2487 memberTag = memberList.method_68582(i);
			String uuid = memberTag.method_68564("uuid", "");
			try {
				members.put(UUID.fromString(uuid), memberTag.method_68564("name", ""));
			} catch (IllegalArgumentException ignored) {
			}
		}

		return new GlowZone(
			UUID.fromString(tag.method_68564("id", UUID.randomUUID().toString())),
			class_5321.method_29179(class_7924.field_41223, class_2960.method_60654(tag.method_68564("world", "minecraft:overworld"))),
			UUID.fromString(tag.method_68564("owner_uuid", UUID.randomUUID().toString())),
			tag.method_68564("owner_name", ""),
			tag.method_68564("name", ""),
			anchors,
			tag.method_68083("interaction_progress", 0),
			members,
			tag.method_68566("hostile_to_non_members", false),
			tag.method_68080("remaining_active_ticks", 0),
			tag.method_68080("last_updated_tick", -1),
			tag.method_68083("hostile_player_deaths_remaining", 0)
		);
	}

	public static class_238 computeBounds(Collection<class_2338> anchors) {
		int minX = anchors.stream().mapToInt(class_2338::method_10263).min().orElse(0);
		int maxX = anchors.stream().mapToInt(class_2338::method_10263).max().orElse(0);
		int minY = anchors.stream().mapToInt(class_2338::method_10264).min().orElse(0);
		int maxY = anchors.stream().mapToInt(class_2338::method_10264).max().orElse(0);
		int minZ = anchors.stream().mapToInt(class_2338::method_10260).min().orElse(0);
		int maxZ = anchors.stream().mapToInt(class_2338::method_10260).max().orElse(0);
		return new class_238(minX, minY, minZ, maxX, maxY, maxZ);
	}

	public static Set<class_1923> computeChunks(class_238 bounds) {
		int minChunkX = ((int) Math.floor(bounds.field_1323)) >> 4;
		int maxChunkX = ((int) Math.floor(bounds.field_1320)) >> 4;
		int minChunkZ = ((int) Math.floor(bounds.field_1321)) >> 4;
		int maxChunkZ = ((int) Math.floor(bounds.field_1324)) >> 4;

		Set<class_1923> chunks = new LinkedHashSet<>();
		for (int chunkX = minChunkX; chunkX <= maxChunkX; chunkX++) {
			for (int chunkZ = minChunkZ; chunkZ <= maxChunkZ; chunkZ++) {
				chunks.add(new class_1923(chunkX, chunkZ));
			}
		}
		return chunks;
	}

	public static List<class_2338> sortedAnchors(Collection<class_2338> anchors) {
		return anchors.stream()
			.sorted(Comparator.comparingInt(class_2338::method_10264)
				.thenComparingInt(class_2338::method_10263)
				.thenComparingInt(class_2338::method_10260))
			.toList();
	}
}
