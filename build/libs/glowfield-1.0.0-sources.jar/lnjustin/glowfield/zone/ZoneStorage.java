package lnjustin.glowfield.zone;

import lnjustin.glowfield.GlowField;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2505;
import net.minecraft.class_2507;
import net.minecraft.server.MinecraftServer;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class ZoneStorage {
	private static final String FILE_NAME = "glowfield_zones.nbt";

	private ZoneStorage() {
	}

	public static void save(MinecraftServer server, Iterable<GlowZone> zones) {
		Path file = server.method_3831().resolve(FILE_NAME);
		class_2487 root = new class_2487();
		class_2499 zoneList = new class_2499();

		for (GlowZone zone : zones) {
			class_2487 zoneTag = new class_2487();
			zone.writeNbt(zoneTag);
			zoneList.add(zoneTag);
		}

		root.method_10566("zones", zoneList);
		try {
			class_2507.method_30614(root, file);
		} catch (Exception exception) {
			GlowField.LOGGER.error("Failed to save GlowField zones", exception);
		}
	}

	public static List<GlowZone> load(MinecraftServer server) {
		Path file = server.method_3831().resolve(FILE_NAME);
		if (Files.notExists(file)) {
			return List.of();
		}

		try {
			class_2487 root = class_2507.method_30613(file, class_2505.method_53898());
			class_2499 zoneList = root.method_68569("zones");
			List<GlowZone> zones = new ArrayList<>(zoneList.size());
			for (int i = 0; i < zoneList.size(); i++) {
				zones.add(GlowZone.fromNbt(zoneList.method_68582(i)));
			}
			return zones;
		} catch (Exception exception) {
			GlowField.LOGGER.error("Failed to load GlowField zones", exception);
			return List.of();
		}
	}
}
