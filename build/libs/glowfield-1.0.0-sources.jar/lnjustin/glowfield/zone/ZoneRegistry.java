package lnjustin.glowfield.zone;

import lnjustin.glowfield.config.GlowFieldConfig;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2394;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.class_4969;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class ZoneRegistry {
	private final GlowFieldConfig config;
	private final Map<UUID, GlowZone> zones = new LinkedHashMap<>();
	private final Map<class_5321<class_1937>, Map<class_1923, Set<UUID>>> chunkIndex = new HashMap<>();
	private final Map<class_5321<class_1937>, Map<class_2338, Set<UUID>>> anchorToZones = new HashMap<>();
	private final Map<class_5321<class_1937>, Map<Integer, Set<class_2338>>> anchorsByY = new HashMap<>();
	private final Map<class_5321<class_1937>, Set<UUID>> loadedZoneIds = new HashMap<>();
	private final Map<ZoneSignature, UUID> zoneSignatures = new HashMap<>();
	private final Map<PendingPlacementKey, PlacementClaim> pendingPlacements = new HashMap<>();
	private final Map<PendingHostileActivationKey, Set<class_2338>> pendingHostileActivations = new HashMap<>();
	private final Map<UUID, ZoneDamageRecord> recentPlayerZoneDamage = new HashMap<>();
	private final Map<AnchorDamageKey, AnchorDamageProgress> anchorDamage = new HashMap<>();
	private final Map<UUID, Long> lastHostileDamageTicks = new HashMap<>();
	private MinecraftServer server;
	private boolean dirty;

	public ZoneRegistry(GlowFieldConfig config) {
		this.config = config;
	}

	public void load(MinecraftServer server) {
		this.server = server;
		clearRuntimeState();
		for (GlowZone zone : ZoneStorage.load(server)) {
			class_3218 world = server.method_3847(zone.worldKey());
			if (world == null || !validateZone(world, zone.anchors())) {
				continue;
			}
			registerZone(zone);
		}
		dirty = false;
	}

	public void save(MinecraftServer server) {
		syncZonesForSave(server);
		if (!dirty) {
			return;
		}
		ZoneStorage.save(server, zones.values());
		dirty = false;
	}

	public void onChunkLoad(class_3218 world, class_2818 chunk) {
		indexChunkAnchors(world, chunk);
		loadedZoneIds
			.computeIfAbsent(world.method_27983(), key -> new HashSet<>())
			.addAll(chunkIndex.computeIfAbsent(world.method_27983(), key -> new HashMap<>()).getOrDefault(chunk.method_12004(), Set.of()));
	}

	public void onChunkUnload(class_3218 world, class_2818 chunk) {
		Set<UUID> active = loadedZoneIds.computeIfAbsent(world.method_27983(), key -> new HashSet<>());
		active.removeAll(chunkIndex.computeIfAbsent(world.method_27983(), key -> new HashMap<>()).getOrDefault(chunk.method_12004(), Set.of()));
	}

	public void onEndWorldTick(class_3218 world) {
		boolean changed = false;
		for (GlowZone zone : loadedZones(world)) {
			long before = zone.remainingActiveTicks();
			zone.syncRuntime(world, config);
			maybeNotifyZoneMode(world, zone);
			if (zone.remainingActiveTicks() != before) {
				changed = true;
			}
		}
		if (changed) {
			dirty = true;
		}

		long time = world.method_75260();
		if (config.particlesEnabled && time % config.particleIntervalTicks == 0) {
			renderWorldParticles(world);
		}
		if (time % config.entitySweepIntervalTicks == 0) {
			sweepWorldEntities(world);
		}
		if (time % config.saveFlushIntervalTicks == 0 && server != null) {
			save(server);
		}
	}

	public void onEntityLoad(class_1297 entity, class_3218 world) {
		GlowZone zone = findFirstZoneContaining(world, entity.method_5829());
		if (zone == null || !(entity instanceof class_1308 mob)) {
			return;
		}
		if (config.suppressMobSpawns && zone.state(world, config) != ZoneState.INACTIVE) {
			mob.method_31472();
			recordZoneInteraction(world, zone, 1);
		}
	}

	public void onPlayerJoin(class_3222 player) {
		findFirstZoneContaining((class_3218) player.method_51469(), player.method_5829());
	}

	public void onEntityDeath(class_1309 entity, class_1282 source) {
		if (!(entity instanceof class_3222 player)) {
			return;
		}

		ZoneDamageRecord record = recentPlayerZoneDamage.remove(player.method_5667());
		if (record == null) {
			return;
		}

		class_3218 world = (class_3218) player.method_51469();
		if (world.method_75260() - record.recordedTick() > Math.max(40, config.entitySweepIntervalTicks * 4L)) {
			return;
		}

		GlowZone zone = zones.get(record.zoneId());
		if (zone == null || !zone.worldKey().equals(world.method_27983())) {
			return;
		}

		if (zone.consumesPlayerDeath(world, config)) {
			dirty = true;
		}
	}

	public boolean allowDamage(class_1309 entity, class_1282 source, float amount) {
		if (config.pvpEnabled || !(entity instanceof class_3222 targetPlayer)) {
			return true;
		}
		class_1297 attacker = source.method_5529();
		if (!(attacker instanceof class_3222 attackingPlayer)) {
			return true;
		}

		GlowZone targetZone = findFirstZoneContaining((class_3218) targetPlayer.method_51469(), targetPlayer.method_5829());
		GlowZone attackerZone = findFirstZoneContaining((class_3218) attackingPlayer.method_51469(), attackingPlayer.method_5829());
		return targetZone == null && attackerZone == null;
	}

	public boolean beforeBlockBreak(class_3218 world, class_3222 player, class_2338 pos, class_2680 state) {
		if (!state.method_27852(class_2246.field_23152)) {
			return true;
		}

		GlowZone hostileZone = findHostileZoneForAnchor(world, pos, player.method_5667());
		if (hostileZone == null) {
			return true;
		}

		AnchorDamageKey key = new AnchorDamageKey(world.method_27983(), pos.method_10062());
		AnchorDamageProgress progress = anchorDamage.computeIfAbsent(key, unused -> new AnchorDamageProgress(0, world.method_75260()));
		progress = decayedProgress(progress, world.method_75260());
		int nextHits = progress.hits() + 1;
		if (nextHits >= Math.max(1, config.anchorBreakHitsRequired)) {
			anchorDamage.remove(key);
			dirty = true;
			return true;
		}

		anchorDamage.put(key, new AnchorDamageProgress(nextHits, world.method_75260()));
		applyAnchorBacklash(world, pos, player, hostileZone);
		player.method_7353(class_2561.method_43470("Anchor Damage: " + nextHits + "/" + Math.max(1, config.anchorBreakHitsRequired) + "."), true);
		dirty = true;
		return false;
	}

	public void onBlockBroken(class_3218 world, class_2338 pos, class_2680 oldState, @Nullable class_3222 player) {
		if (oldState.method_27852(class_2246.field_23152)) {
			anchorDamage.remove(new AnchorDamageKey(world.method_27983(), pos.method_10062()));
			triggerAnchorDestroyedExplosion(world, pos, player);
			handleAnchorTransition(world, pos, oldState, class_2246.field_10124.method_9564(), player);
		}
	}

	public class_1269 onUseBlock(class_3218 world, class_3222 player, class_1268 hand, class_3965 hitResult) {
		class_1799 stack = player.method_5998(hand);
		class_2338 hitPos = hitResult.method_17777();
		class_2680 state = world.method_8320(hitPos);

		if (stack.method_31574(class_1802.field_23141)) {
			recordPotentialAnchorPlacement(world, player, hitPos);
			recordPotentialAnchorPlacement(world, player, hitPos.method_10093(hitResult.method_17780()));
			return class_1269.field_5811;
		}

		if (config.nameTagNamingEnabled && stack.method_31574(class_1802.field_8448) && stack.method_65130() != null && state.method_27852(class_2246.field_23152)) {
			GlowZone zone = findOwnedZoneByAnchor(world, hitPos, player.method_5667());
			if (zone == null) {
				return class_1269.field_5811;
			}

			renameZone(zone.id(), stack.method_65130().getString());
			player.method_7353(class_2561.method_43470("Zone renamed to " + describeZone(zone.id()) + "."), false);
			return class_1269.field_5812;
		}

		if (state.method_27852(class_2246.field_23152)
			&& config.allowNonMemberPlayerDamage
			&& stack.method_31574(config.hostileFieldActivationItem())) {
			return handleHostileFieldActivation(world, player, hand, hitPos);
		}

		return class_1269.field_5811;
	}

	public void onAnchorStateChanged(class_3218 world, class_2338 pos, class_2680 oldState, class_2680 newState) {
		handleAnchorTransition(world, pos, oldState, newState, consumePendingOwner(world, pos));
	}

	@Nullable
	public GlowZone findZoneContaining(class_3222 player) {
		return findFirstZoneContaining((class_3218) player.method_51469(), player.method_5829());
	}

	@Nullable
	public GlowZone findOwnedZoneContaining(class_3222 player) {
		GlowZone zone = findZoneContaining(player);
		if (zone == null || !zone.ownerUuid().equals(player.method_5667())) {
			return null;
		}

		zone.setOwnerName(player.method_7334().name());
		return zone;
	}

	public List<GlowZone> listOwnedZones(UUID ownerUuid) {
		return zones.values().stream()
			.filter(zone -> zone.ownerUuid().equals(ownerUuid))
			.sorted(Comparator.comparing(GlowZone::name).thenComparing(zone -> zone.id().toString()))
			.toList();
	}

	public void renameZone(UUID zoneId, String name) {
		GlowZone zone = zones.get(zoneId);
		if (zone == null) {
			return;
		}
		zone.setName(name);
		dirty = true;
	}

	public boolean addMember(UUID zoneId, class_3222 member) {
		GlowZone zone = zones.get(zoneId);
		if (zone == null) {
			return false;
		}
		zone.addMember(member.method_5667(), member.method_7334().name());
		dirty = true;
		return true;
	}

	public boolean removeMember(UUID zoneId, UUID memberUuid) {
		GlowZone zone = zones.get(zoneId);
		if (zone == null || !zone.members().containsKey(memberUuid)) {
			return false;
		}
		zone.removeMember(memberUuid);
		dirty = true;
		return true;
	}

	public void removeZone(UUID zoneId) {
		GlowZone zone = zones.remove(zoneId);
		if (zone == null) {
			return;
		}

		zoneSignatures.remove(ZoneSignature.of(zone.worldKey(), zone.anchors()));
		removeZoneIndexes(zone);
		dirty = true;
	}

	private class_1269 handleHostileFieldActivation(class_3218 world, class_3222 player, class_1268 hand, class_2338 anchor) {
		GlowZone zone = findOwnedZoneByAnchor(world, anchor, player.method_5667());
		if (zone == null) {
			return class_1269.field_5811;
		}
		if (zone.hostileToNonMembers()) {
			player.method_7353(class_2561.method_43470("Zone " + describeZone(zone.id()) + " is already overcharged to be hostile against non-members."), false);
			return class_1269.field_5812;
		}
		if (zone.state(world, config) != ZoneState.FORCE_FIELD) {
			player.method_7353(class_2561.method_43470("The zone must be fully charged before it can be hostile against non-members."), false);
			return class_1269.field_5812;
		}

		class_1799 stack = player.method_5998(hand);
		if (stack.method_7960()) {
			return class_1269.field_5811;
		}

		PendingHostileActivationKey key = new PendingHostileActivationKey(zone.id(), player.method_5667());
		Set<class_2338> activatedAnchors = pendingHostileActivations.computeIfAbsent(key, unused -> new HashSet<>());
		class_2338 immutableAnchor = anchor.method_10062();
		if (activatedAnchors.contains(immutableAnchor)) {
			player.method_7353(class_2561.method_43470("That anchor is already overcharged for hostility against non-members."), false);
			return class_1269.field_5812;
		}

		activatedAnchors.add(immutableAnchor);
		stack.method_7934(1);
		dirty = true;

		if (activatedAnchors.containsAll(zone.anchors())) {
			zone.armAgainstNonMembers(world, config);
			pendingHostileActivations.remove(key);
			player.method_7353(class_2561.method_43470("Zone " + describeZone(zone.id()) + " is now overcharged for hostile mode against non-members."), false);
			maybeNotifyZoneMode(world, zone);
		} else {
			player.method_7353(class_2561.method_43470("Overcharged " + activatedAnchors.size() + "/" + zone.anchors().size() + " anchors of " + describeZone(zone.id()) + " to be hostile against non-members."), false);
		}

		return class_1269.field_5812;
	}

	public String describeZone(@Nullable UUID zoneId) {
		GlowZone zone = zoneId == null ? null : zones.get(zoneId);
		if (zone == null) {
			return "unnamed zone";
		}
		return zone.name().isBlank() ? zone.id().toString() : zone.name();
	}

	public String describeZoneVerbose(GlowZone zone) {
		return "Zone " + describeZone(zone.id())
			+ " owner=" + zone.ownerName()
			+ " world=" + zone.worldKey().method_29177()
			+ " anchors=" + GlowZone.sortedAnchors(zone.anchors())
			+ " members=" + zone.members().values()
			+ " hostile=" + zone.hostileToNonMembers()
			+ " remaining_ticks=" + zone.remainingActiveTicks();
	}

	private void handleAnchorTransition(class_3218 world, class_2338 pos, class_2680 oldState, class_2680 newState, @Nullable class_3222 owner) {
		boolean wasAnchor = oldState.method_27852(class_2246.field_23152);
		boolean isAnchor = newState.method_27852(class_2246.field_23152);
		if (!wasAnchor && !isAnchor) {
			return;
		}

		if (!wasAnchor) {
			addAnchor(world.method_27983(), pos);
			discoverZonesAt(world, pos.method_10062(), owner);
			dirty = true;
			return;
		}

		if (!isAnchor) {
			removeAnchor(world.method_27983(), pos);
			removeZonesForAnchor(world.method_27983(), pos);
			dirty = true;
			return;
		}

		if (oldState.method_28498(class_4969.field_23153) && newState.method_28498(class_4969.field_23153)
			&& !oldState.method_11654(class_4969.field_23153).equals(newState.method_11654(class_4969.field_23153))) {
			resetZonesForAnchor(world, pos);
			dirty = true;
		}
	}

	private void discoverZonesAt(class_3218 world, class_2338 pivot, @Nullable class_3222 owner) {
		if (owner == null) {
			return;
		}

		Set<class_2338> samePlane = anchorsByY.computeIfAbsent(world.method_27983(), key -> new HashMap<>()).getOrDefault(pivot.method_10264(), Set.of());
		if (samePlane.size() < 4) {
			return;
		}

		for (class_2338 candidate : samePlane) {
			if (candidate.equals(pivot) || candidate.method_10263() == pivot.method_10263() || candidate.method_10260() == pivot.method_10260()) {
				continue;
			}

			Set<class_2338> anchors = Set.of(
				pivot,
				candidate,
				new class_2338(pivot.method_10263(), pivot.method_10264(), candidate.method_10260()),
				new class_2338(candidate.method_10263(), pivot.method_10264(), pivot.method_10260())
			);

			if (!samePlane.containsAll(anchors) || !validateZone(world, anchors)) {
				continue;
			}

			ZoneSignature signature = ZoneSignature.of(world.method_27983(), anchors);
			if (zoneSignatures.containsKey(signature)) {
				continue;
			}

			GlowZone zone = new GlowZone(UUID.randomUUID(), world.method_27983(), owner.method_5667(), owner.method_7334().name(), "", anchors, 0);
			registerZone(zone);
			dirty = true;
			owner.method_7353(class_2561.method_43470("Created GlowField zone " + describeZone(zone.id()) + "."), false);
		}
	}

	private void renderWorldParticles(class_3218 world) {
		for (GlowZone zone : loadedZones(world)) {
			ZoneState state = zone.state(world, config);
			if (state == ZoneState.INACTIVE) {
				continue;
			}
			renderZoneParticles(world, zone, state);
		}
	}

	private void sweepWorldEntities(class_3218 world) {
		for (GlowZone zone : loadedZones(world)) {
			ZoneState state = zone.state(world, config);
			if (state == ZoneState.INACTIVE) {
				continue;
			}

			for (class_1297 entity : world.method_8333(null, zone.runtimeBounds(world).method_1014(1.0), checked -> !checked.method_7325() && !(checked instanceof class_3222))) {
				if (!zone.contains(entity.method_24515())) {
					continue;
				}
				applyZoneEffects(world, zone, state, entity);
			}

			for (class_3222 player : world.method_18456()) {
				if (player.method_7325() || !zone.contains(player.method_24515())) {
					continue;
				}
				logHostileZoneCheck(world, zone, state, player, "player-inside-zone");
				applyZoneEffects(world, zone, state, player);
			}
		}
	}

	private void applyZoneEffects(class_3218 world, GlowZone zone, ZoneState state, class_1297 entity) {
		if (entity instanceof class_1308 mob) {
			if (config.damageMobs && state == ZoneState.FORCE_FIELD) {
				boolean wasAlive = mob.method_5805();
				mob.method_64397(world, world.method_48963().method_48831(), Float.MAX_VALUE);
				if (wasAlive && !mob.method_5805()) {
					recordZoneInteraction(world, zone, 1);
				}
			}
			return;
		}

		if (entity instanceof class_3222 player && state == ZoneState.FORCE_FIELD) {
			boolean hostileActive = zone.isHostileProtectionActive(world, config);
			boolean member = zone.isMember(player.method_5667());
			logHostileZoneCheck(world, zone, state, player, "apply-effects hostileActive=" + hostileActive + " member=" + member);
			if (hostileActive && !member) {
				long now = world.method_75260();
				Long lastTick = lastHostileDamageTicks.get(player.method_5667());
				boolean intervalElapsed = lastTick == null
					|| config.hostileFieldDamageIntervalTicks <= 0
					|| now >= lastTick + config.hostileFieldDamageIntervalTicks;
				if (intervalElapsed) {
					debugLog(
						"damaging non-member player={} zone={} now={} lastTick={} interval={} damage={}",
						player.method_7334().name(),
						describeZone(zone.id()),
						now,
						lastTick,
						config.hostileFieldDamageIntervalTicks,
						config.hostileFieldDamage
					);
					player.method_64397(world, world.method_48963().method_48831(), (float) config.hostileFieldDamage);
					recentPlayerZoneDamage.put(player.method_5667(), new ZoneDamageRecord(zone.id(), now));
					lastHostileDamageTicks.put(player.method_5667(), now);
					dirty = true;
				} else {
					debugLog(
						"skipped hostile damage due to interval player={} zone={} now={} lastTick={} interval={}",
						player.method_7334().name(),
						describeZone(zone.id()),
						now,
						lastTick,
						config.hostileFieldDamageIntervalTicks
					);
				}
				return;
			}

			if (config.damagePlayers) {
				player.method_64397(world, world.method_48963().method_48831(), (float) config.forceFieldDamage);
			}
		}
	}

	private void recordZoneInteraction(class_3218 world, GlowZone zone, int interactions) {
		if (zone.recordInteractionAndShouldDegrade(interactions, config)) {
			for (class_2338 anchor : zone.anchors()) {
				class_2680 state = world.method_8320(anchor);
				if (state.method_27852(class_2246.field_23152) && state.method_28498(class_4969.field_23153)) {
					int nextCharge = Math.max(0, state.method_11654(class_4969.field_23153) - 1);
					world.method_8501(anchor, state.method_11657(class_4969.field_23153, nextCharge));
				}
			}
		}
		dirty = true;
	}

	private void renderZoneParticles(class_3218 world, GlowZone zone, ZoneState state) {
		if (!shouldRenderParticlesForState(state)) {
			return;
		}

		class_2394 particle = zone.isHostileProtectionActive(world, config) ? config.hostileFieldParticle() : config.particleFor(state);
		class_238 bounds = zone.particleBounds(config);
		double step = Math.max(0.5, config.particleStep);

		if (config.renderVerticalParticleEdges) {
			for (double x = bounds.field_1323; x <= bounds.field_1320; x += step) {
				spawnColumn(world, particle, x, particleColumnMinY(world, bounds, x, bounds.field_1321), bounds.field_1325, bounds.field_1321);
				spawnColumn(world, particle, x, particleColumnMinY(world, bounds, x, bounds.field_1324), bounds.field_1325, bounds.field_1324);
			}
			for (double z = bounds.field_1321; z <= bounds.field_1324; z += step) {
				spawnColumn(world, particle, bounds.field_1323, particleColumnMinY(world, bounds, bounds.field_1323, z), bounds.field_1325, z);
				spawnColumn(world, particle, bounds.field_1320, particleColumnMinY(world, bounds, bounds.field_1320, z), bounds.field_1325, z);
			}
		}

		if (config.renderBottomParticleFace || config.renderTopParticleFace) {
			for (double x = bounds.field_1323; x <= bounds.field_1320; x += step) {
				for (double z = bounds.field_1321; z <= bounds.field_1324; z += step) {
					if (config.renderBottomParticleFace) {
						world.method_65096(particle, x + 0.5, bounds.field_1322 + 0.5, z + 0.5, 1, 0, 0, 0, 0);
					}
					if (config.renderTopParticleFace) {
						world.method_65096(particle, x + 0.5, bounds.field_1325 + 0.5, z + 0.5, 1, 0, 0, 0, 0);
					}
				}
			}
		}
	}

	private boolean shouldRenderParticlesForState(ZoneState state) {
		return switch (state) {
			case INACTIVE -> false;
			case PARTIAL -> config.renderParticlesForPartialState;
			case FORCE_FIELD -> config.renderParticlesForForceFieldState;
			case DEGRADING -> config.renderParticlesForDegradingState;
		};
	}

	private double particleColumnMinY(class_3218 world, class_238 bounds, double x, double z) {
		if (!config.renderParticlesDownToGround) {
			return bounds.field_1322;
		}

		int blockX = class_2338.method_49637(x, bounds.field_1322, z).method_10263();
		int blockZ = class_2338.method_49637(x, bounds.field_1322, z).method_10260();
		int topOpenY = world.method_8624(class_2902.class_2903.field_13203, blockX, blockZ);
		int groundY = Math.max(world.method_31607(), topOpenY - 1);
		return Math.min(bounds.field_1322, groundY);
	}

	private void spawnColumn(class_3218 world, class_2394 particle, double x, double minY, double maxY, double z) {
		double step = Math.max(0.5, config.particleStep);
		double lastY = Double.NEGATIVE_INFINITY;
		for (double y = minY; y <= maxY; y += step) {
			world.method_65096(particle, x + 0.5, y + 0.5, z + 0.5, 1, 0, 0, 0, 0);
			lastY = y;
		}
		if (Math.abs(lastY - maxY) > 1.0E-4) {
			world.method_65096(particle, x + 0.5, maxY + 0.5, z + 0.5, 1, 0, 0, 0, 0);
		}
	}

	private void triggerAnchorDestroyedExplosion(class_3218 world, class_2338 pos, @Nullable class_3222 player) {
		if (config.anchorDestroyedExplosionPower <= 0) {
			return;
		}
		if (player == null) {
			return;
		}

		boolean shouldExplode = false;
		for (UUID zoneId : anchorToZones.computeIfAbsent(world.method_27983(), key -> new HashMap<>()).getOrDefault(pos, Set.of())) {
			GlowZone zone = zones.get(zoneId);
			if (zone != null && zone.isHostileProtectionActive(world, config) && !zone.isMember(player.method_5667())) {
				shouldExplode = true;
				break;
			}
		}
		if (!shouldExplode) {
			return;
		}

		world.method_8537(
			null,
			pos.method_10263() + 0.5,
			pos.method_10264() + 0.5,
			pos.method_10260() + 0.5,
			(float) config.anchorDestroyedExplosionPower,
			config.anchorDestroyedExplosionCreatesFire,
			class_1937.class_7867.field_40891
		);
	}

	private void registerZone(GlowZone zone) {
		zones.put(zone.id(), zone);
		zoneSignatures.put(ZoneSignature.of(zone.worldKey(), zone.anchors()), zone.id());
		loadedZoneIds.computeIfAbsent(zone.worldKey(), key -> new HashSet<>()).add(zone.id());

		for (class_2338 anchor : zone.anchors()) {
			addAnchor(zone.worldKey(), anchor);
			anchorToZones
				.computeIfAbsent(zone.worldKey(), key -> new HashMap<>())
				.computeIfAbsent(anchor, key -> new LinkedHashSet<>())
				.add(zone.id());
		}

		for (class_1923 chunkPos : zone.coveredChunks()) {
			chunkIndex
				.computeIfAbsent(zone.worldKey(), key -> new HashMap<>())
				.computeIfAbsent(chunkPos, key -> new LinkedHashSet<>())
				.add(zone.id());
		}
	}

	private void removeZoneIndexes(GlowZone zone) {
		Map<class_2338, Set<UUID>> zoneAnchors = anchorToZones.get(zone.worldKey());
		if (zoneAnchors != null) {
			for (class_2338 anchor : zone.anchors()) {
				Set<UUID> ids = zoneAnchors.get(anchor);
				if (ids != null) {
					ids.remove(zone.id());
					if (ids.isEmpty()) {
						zoneAnchors.remove(anchor);
					}
				}
			}
		}

		Map<class_1923, Set<UUID>> zoneChunks = chunkIndex.get(zone.worldKey());
		if (zoneChunks != null) {
			for (class_1923 chunkPos : zone.coveredChunks()) {
				Set<UUID> ids = zoneChunks.get(chunkPos);
				if (ids != null) {
					ids.remove(zone.id());
					if (ids.isEmpty()) {
						zoneChunks.remove(chunkPos);
					}
				}
			}
		}

		Set<UUID> active = loadedZoneIds.get(zone.worldKey());
		if (active != null) {
			active.remove(zone.id());
		}
	}

	private void removeZonesForAnchor(class_5321<class_1937> worldKey, class_2338 anchor) {
		Set<UUID> ids = new HashSet<>(anchorToZones.computeIfAbsent(worldKey, key -> new HashMap<>()).getOrDefault(anchor, Set.of()));
		for (UUID zoneId : ids) {
			removeZone(zoneId);
		}
	}

	private void applyAnchorBacklash(class_3218 world, class_2338 anchor, class_3222 player, GlowZone zone) {
		if (config.backlashDamage > 0) {
			player.method_64397(world, world.method_48963().method_48831(), (float) config.backlashDamage);
			recentPlayerZoneDamage.put(player.method_5667(), new ZoneDamageRecord(zone.id(), world.method_75260()));
		}

		if (config.backlashKnockback > 0) {
			double dx = player.method_23317() - (anchor.method_10263() + 0.5);
			double dz = player.method_23321() - (anchor.method_10260() + 0.5);
			if (Math.abs(dx) < 1.0E-4 && Math.abs(dz) < 1.0E-4) {
				dz = 1.0;
			}
			player.method_6005(config.backlashKnockback, dx, dz);
		}

		if (config.backlashSlownessTicks > 0) {
			player.method_6092(new class_1293(class_1294.field_5909, config.backlashSlownessTicks, Math.max(0, config.backlashSlownessAmplifier)));
		}
		if (config.backlashWitherTicks > 0) {
			player.method_6092(new class_1293(class_1294.field_5920, config.backlashWitherTicks, Math.max(0, config.backlashWitherAmplifier)));
		}
	}

	@Nullable
	private GlowZone findHostileZoneForAnchor(class_3218 world, class_2338 anchor, UUID playerUuid) {
		for (UUID zoneId : anchorToZones.computeIfAbsent(world.method_27983(), key -> new HashMap<>()).getOrDefault(anchor, Set.of())) {
			GlowZone zone = zones.get(zoneId);
			if (zone != null && !zone.isMember(playerUuid) && zone.isHostileProtectionActive(world, config)) {
				return zone;
			}
		}
		return null;
	}

	private AnchorDamageProgress decayedProgress(AnchorDamageProgress progress, long currentTick) {
		if (!config.hitDecayEnabled || progress.hits() <= 0 || config.hitDecayTimeTicks <= 0) {
			return progress;
		}

		long elapsed = Math.max(0, currentTick - progress.lastUpdatedTick());
		int decayedHits = Math.max(0, progress.hits() - (int) (elapsed / config.hitDecayTimeTicks));
		long updatedTick = decayedHits == progress.hits() ? progress.lastUpdatedTick() : currentTick;
		return new AnchorDamageProgress(decayedHits, updatedTick);
	}

	private void resetZonesForAnchor(class_3218 world, class_2338 anchor) {
		Set<UUID> ids = anchorToZones.computeIfAbsent(world.method_27983(), key -> new HashMap<>()).getOrDefault(anchor, Set.of());
		for (UUID zoneId : ids) {
			GlowZone zone = zones.get(zoneId);
			if (zone != null) {
				zone.resetForCurrentCharge(world, config);
				pendingHostileActivations.entrySet().removeIf(entry -> entry.getKey().zoneId().equals(zoneId));
				maybeNotifyZoneMode(world, zone);
			}
		}
	}

	private void maybeNotifyZoneMode(class_3218 world, GlowZone zone) {
		if (server == null || !zone.worldKey().equals(world.method_27983())) {
			return;
		}

		String modeKey = zone.currentModeKey(world, config);
		if (!zone.markModeAnnounced(modeKey)) {
			return;
		}

		class_3222 owner = server.method_3760().method_14602(zone.ownerUuid());
		if (owner == null) {
			return;
		}

		owner.method_7353(class_2561.method_43470("Zone " + describeZone(zone.id()) + " is now in " + zone.currentModeLabel(world, config) + "."), false);
	}

	private void logHostileZoneCheck(class_3218 world, GlowZone zone, ZoneState state, class_3222 player, String context) {
		debugLog(
			"{} player={} zone={} state={} mode={} hostileFlag={} hostileActive={} member={} pos={} remainingTicks={} deathsRemaining={}",
			context,
			player.method_7334().name(),
			describeZone(zone.id()),
			state.serializedName(),
			zone.currentModeKey(world, config),
			zone.hostileToNonMembers(),
			zone.isHostileProtectionActive(world, config),
			zone.isMember(player.method_5667()),
			player.method_24515(),
			zone.remainingActiveTicks(),
			zone.hostilePlayerDeathsRemaining()
		);
	}

	private void debugLog(String message, Object... args) {
		if (!config.debugLoggingEnabled) {
			return;
		}
		lnjustin.glowfield.GlowField.LOGGER.info("[GlowField debug] " + message, args);
	}

	private void addAnchor(class_5321<class_1937> worldKey, class_2338 pos) {
		anchorsByY
			.computeIfAbsent(worldKey, key -> new HashMap<>())
			.computeIfAbsent(pos.method_10264(), key -> new LinkedHashSet<>())
			.add(pos.method_10062());
	}

	private void removeAnchor(class_5321<class_1937> worldKey, class_2338 pos) {
		Map<Integer, Set<class_2338>> byY = anchorsByY.get(worldKey);
		if (byY == null) {
			return;
		}
		Set<class_2338> anchors = byY.get(pos.method_10264());
		if (anchors != null) {
			anchors.remove(pos);
			if (anchors.isEmpty()) {
				byY.remove(pos.method_10264());
			}
		}
	}

	private void indexChunkAnchors(class_3218 world, class_2818 chunk) {
		int startX = chunk.method_12004().method_8326();
		int startZ = chunk.method_12004().method_8328();
		int bottomY = world.method_31607();
		int topY = world.method_31600();

		for (int x = 0; x < 16; x++) {
			for (int z = 0; z < 16; z++) {
					for (int y = bottomY; y <= topY; y++) {
						class_2338 pos = new class_2338(startX + x, y, startZ + z);
						if (chunk.method_8320(pos).method_27852(class_2246.field_23152)) {
							addAnchor(world.method_27983(), pos);
						}
					}
			}
		}
	}

	private boolean validateZone(class_3218 world, Collection<class_2338> anchors) {
		if (anchors.size() != 4) {
			return false;
		}

		Set<Integer> xs = new HashSet<>();
		Set<Integer> ys = new HashSet<>();
		Set<Integer> zs = new HashSet<>();
		for (class_2338 anchor : anchors) {
			if (!world.method_8320(anchor).method_27852(class_2246.field_23152)) {
				return false;
			}
			xs.add(anchor.method_10263());
			ys.add(anchor.method_10264());
			zs.add(anchor.method_10260());
		}

		if (xs.size() != 2 || ys.size() != 1 || zs.size() != 2) {
			return false;
		}

		List<Integer> orderedX = xs.stream().sorted().toList();
		List<Integer> orderedZ = zs.stream().sorted().toList();
		int y = ys.iterator().next();
		Set<class_2338> expected = Set.of(
			new class_2338(orderedX.get(0), y, orderedZ.get(0)),
			new class_2338(orderedX.get(0), y, orderedZ.get(1)),
			new class_2338(orderedX.get(1), y, orderedZ.get(0)),
			new class_2338(orderedX.get(1), y, orderedZ.get(1))
		);
		return expected.equals(new HashSet<>(anchors));
	}

	@Nullable
	private GlowZone findFirstZoneContaining(class_3218 world, class_238 box) {
		int minChunkX = class_2338.method_49637(box.field_1323, 0, 0).method_10263() >> 4;
		int maxChunkX = class_2338.method_49637(box.field_1320, 0, 0).method_10263() >> 4;
		int minChunkZ = class_2338.method_49637(0, 0, box.field_1321).method_10260() >> 4;
		int maxChunkZ = class_2338.method_49637(0, 0, box.field_1324).method_10260() >> 4;

		Map<class_1923, Set<UUID>> worldChunks = chunkIndex.computeIfAbsent(world.method_27983(), key -> new HashMap<>());
		Set<UUID> candidates = new LinkedHashSet<>();
		for (int chunkX = minChunkX; chunkX <= maxChunkX; chunkX++) {
			for (int chunkZ = minChunkZ; chunkZ <= maxChunkZ; chunkZ++) {
				candidates.addAll(worldChunks.getOrDefault(new class_1923(chunkX, chunkZ), Set.of()));
			}
		}

		for (UUID zoneId : candidates) {
			GlowZone zone = zones.get(zoneId);
			if (zone != null && zone.contains(world, box)) {
				return zone;
			}
		}
		return null;
	}

	@Nullable
	private GlowZone findOwnedZoneByAnchor(class_3218 world, class_2338 anchor, UUID ownerUuid) {
		for (UUID zoneId : anchorToZones.computeIfAbsent(world.method_27983(), key -> new HashMap<>()).getOrDefault(anchor, Set.of())) {
			GlowZone zone = zones.get(zoneId);
			if (zone != null && zone.ownerUuid().equals(ownerUuid)) {
				return zone;
			}
		}
		return null;
	}

	private List<GlowZone> loadedZones(class_3218 world) {
		List<GlowZone> loaded = new ArrayList<>();
		for (UUID zoneId : loadedZoneIds.computeIfAbsent(world.method_27983(), key -> new HashSet<>())) {
			GlowZone zone = zones.get(zoneId);
			if (zone != null) {
				loaded.add(zone);
			}
		}
		return loaded;
	}

	private void recordPotentialAnchorPlacement(class_3218 world, class_3222 player, class_2338 pos) {
		pendingPlacements.put(new PendingPlacementKey(world.method_27983(), pos.method_10062()), new PlacementClaim(player.method_5667(), world.method_75260()));
	}

	@Nullable
	private class_3222 consumePendingOwner(class_3218 world, class_2338 pos) {
		PlacementClaim claim = pendingPlacements.remove(new PendingPlacementKey(world.method_27983(), pos.method_10062()));
		if (claim == null || world.method_75260() - claim.recordedTick() > 2 || server == null) {
			return null;
		}
		return server.method_3760().method_14602(claim.ownerUuid());
	}

	private void syncZonesForSave(MinecraftServer server) {
		boolean changed = false;
		for (GlowZone zone : zones.values()) {
			class_3218 world = server.method_3847(zone.worldKey());
			if (world == null) {
				continue;
			}

			long before = zone.remainingActiveTicks();
			zone.syncRuntime(world, config);
			if (zone.remainingActiveTicks() != before) {
				changed = true;
			}
		}
		if (changed) {
			dirty = true;
		}
	}

	private void clearRuntimeState() {
		zones.clear();
		chunkIndex.clear();
		anchorToZones.clear();
		anchorsByY.clear();
		loadedZoneIds.clear();
		zoneSignatures.clear();
		pendingPlacements.clear();
		pendingHostileActivations.clear();
		recentPlayerZoneDamage.clear();
		anchorDamage.clear();
		lastHostileDamageTicks.clear();
	}

	private record ZoneSignature(class_5321<class_1937> worldKey, List<class_2338> anchors) {
		private static ZoneSignature of(class_5321<class_1937> worldKey, Collection<class_2338> anchors) {
			return new ZoneSignature(worldKey, GlowZone.sortedAnchors(anchors));
		}
	}

	private record PendingPlacementKey(class_5321<class_1937> worldKey, class_2338 pos) {
	}

	private record PlacementClaim(UUID ownerUuid, long recordedTick) {
	}

	private record PendingHostileActivationKey(UUID zoneId, UUID playerUuid) {
	}

	private record ZoneDamageRecord(UUID zoneId, long recordedTick) {
	}

	private record AnchorDamageKey(class_5321<class_1937> worldKey, class_2338 pos) {
	}

	private record AnchorDamageProgress(int hits, long lastUpdatedTick) {
	}
}
