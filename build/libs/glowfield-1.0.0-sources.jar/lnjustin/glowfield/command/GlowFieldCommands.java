package lnjustin.glowfield.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import lnjustin.glowfield.zone.GlowZone;
import lnjustin.glowfield.zone.ZoneRegistry;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.List;

public final class GlowFieldCommands {
	private GlowFieldCommands() {
	}

	public static void register(CommandDispatcher<class_2168> dispatcher, ZoneRegistry registry) {
		dispatcher.register(class_2170.method_9247("glowfield")
			.then(class_2170.method_9247("setname")
				.then(class_2170.method_9244("name", StringArgumentType.greedyString())
					.executes(context -> {
						class_3222 player = context.getSource().method_9207();
						GlowZone zone = registry.findOwnedZoneContaining(player);
						if (zone == null) {
							context.getSource().method_9213(class_2561.method_43470("You are not inside one of your GlowField zones."));
							return 0;
						}

						String name = StringArgumentType.getString(context, "name").trim();
						registry.renameZone(zone.id(), name);
						context.getSource().method_9226(() -> class_2561.method_43470("Zone renamed to " + registry.describeZone(zone.id()) + "."), false);
						return 1;
					})))
			.then(class_2170.method_9247("info")
				.executes(context -> {
					class_3222 player = context.getSource().method_9207();
					GlowZone zone = registry.findZoneContaining(player);
					if (zone == null) {
						context.getSource().method_9213(class_2561.method_43470("You are not inside a GlowField zone."));
						return 0;
					}

					context.getSource().method_9226(() -> class_2561.method_43470(registry.describeZoneVerbose(zone)), false);
					return 1;
				}))
			.then(class_2170.method_9247("list")
				.executes(context -> {
					class_3222 player = context.getSource().method_9207();
					List<GlowZone> zones = registry.listOwnedZones(player.method_5667());
					if (zones.isEmpty()) {
						context.getSource().method_9226(() -> class_2561.method_43470("You do not own any GlowField zones."), false);
						return 0;
					}

					for (GlowZone zone : zones) {
						context.getSource().method_9226(() -> class_2561.method_43470(registry.describeZoneVerbose(zone)), false);
					}
					return zones.size();
				}))
			.then(class_2170.method_9247("remove")
				.executes(context -> {
					class_3222 player = context.getSource().method_9207();
					GlowZone zone = registry.findOwnedZoneContaining(player);
					if (zone == null) {
						context.getSource().method_9213(class_2561.method_43470("You are not inside one of your GlowField zones."));
						return 0;
					}

					registry.removeZone(zone.id());
					context.getSource().method_9226(() -> class_2561.method_43470("Removed " + registry.describeZone(zone.id()) + "."), true);
					return 1;
				})));
	}
}
